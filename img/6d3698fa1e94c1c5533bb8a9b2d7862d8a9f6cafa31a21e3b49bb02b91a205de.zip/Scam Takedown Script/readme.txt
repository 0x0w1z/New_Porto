Configuration: Replace 'https://' in the send_request function with your target registration endpoint.
Adjust Threads: Modify the num_threads variable in the threads function to control request concurrency.
Run Script: Execute the script using Python
python main.py